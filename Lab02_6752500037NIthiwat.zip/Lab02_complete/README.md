# Lab 02 — Robust Reactive Lamp (ไฟล์ทั้งหมด)

## โครงสร้าง
- report/Lab02_Report.docx, .pdf, .md — รายงาน (ต้องใส่ชื่อกลุ่มและสมาชิกเอง)
- predictions.md — สมมติฐานก่อนทดลอง พร้อมเวลาบันทึก
- tests_before_todo.txt — unit tests ก่อนเติม TODO (12/12 ผ่าน)
- lab_02/ — โฟลเดอร์แล็บทั้งหมด พร้อมรัน
  - student_controller.py — TODO 1–4 เติมแล้ว (grade 10/10)
  - plot_annotated.py, make_report_figures.py — สคริปต์กราฟที่เพิ่ม
  - results/student_grade.json — ผล grade_submission.py
  - results/student_comparison/ — ทดลอง A โหมด student (run_config.json, raw CSV 20 trials, summary)
  - results/comparison/ — ทดลอง A โหมด reference (ไว้เทียบ)
  - results/c2_short/, results/c2_full/ — ทดลอง B ของ C2
  - results/c1_full/, results/c3_full/ — ชุดเสริม
  - results/figures/ — กราฟทั้งหมด

## ที่ต้องทำเอง
1. ใส่ชื่อกลุ่มและสมาชิกในรายงาน
2. รันซ้ำบนเครื่องตัวเอง จากโฟลเดอร์ lab_02 (ผลเท่าเดิม แต่ path ในไฟล์ผลจะเป็นของเครื่องเรา)
   ลบ results\student_grade.json เดิมก่อน เพราะ grader ไม่เขียนทับไฟล์เดิม

   python grade_submission.py --student-file student_controller.py --out results\student_grade.json
   python lab02.py --controller-source student --protocol controller-comparison --out results\student_comparison --overwrite
   python lab02.py --controller-source student --protocol robustness-short --condition C2 --out results\c2_short --overwrite
   python lab02.py --controller-source student --protocol robustness-full --condition C2 --out results\c2_full --overwrite
