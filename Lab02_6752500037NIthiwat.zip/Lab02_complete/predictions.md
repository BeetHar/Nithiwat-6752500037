# Lab 02 — สมมติฐานก่อนทดลอง (Prediction)

บันทึกเมื่อ: 2026-09-30 17:06:31 UTC — ก่อนรันการทดลองและก่อนเปิดไฟล์ผลใด ๆ

ฐานการคำนวณ: ความชันช่วงเข้า/ออก = 0.35 m / 4 s = 0.0875 m/s; physical crossing ที่ 0.35 m ≈ 6.857 s (เข้า) และ 13.143 s (ออก)

1. C1 กับ noise: switching count เพิ่มขึ้นชัดเมื่อ noise เพิ่ม เพราะใช้ raw distance เทียบ threshold เดียว
   ช่วงที่ state สลับได้กว้าง ≈ ±2σ/0.0875 m/s → ±0.23 s (σ=0.01) และ ±0.69 s (σ=0.03)
   ที่ σ=0 จะเหลือ 2 switches พอดี
2. C2: filter (β=0.25) ลด SD noise เหลือ ≈0.38σ และ hysteresis 0.32/0.38 m → false trigger และ extra switches ≈ 0 ที่ σ=0.01
   แลกกับ latency enter/exit ≈ 0.34 s (จาก hysteresis band) + ≈0.06 s (filter lag 3 samples) ≈ 0.40 s
   C1 latency ≈ 0 s แต่ recovery time นานกว่าเพราะ chatter
3. Delay 300 ms: สัญญาณเลื่อน 15 samples → latency ของ C2 เพิ่ม ≈ 0.30 s (≈0.70 s)
   ช่วง 0.3 s แรก buffer ว่าง → invalid samples 15 ค่า/trial (5 ค่าที่ 100 ms)

บันทึกการแก้สมมติฐาน: (ยังไม่มี)
