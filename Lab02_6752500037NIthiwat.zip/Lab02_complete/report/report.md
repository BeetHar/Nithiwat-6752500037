# รายงาน Lab 02 — Robust Reactive Lamp

รายวิชา 1353410 Biological Sensing and Sensorimotor Control · ชื่อกลุ่ม ________ · สมาชิก ________ · วันที่ 1 ตุลาคม 2569

## คำถามวิจัย

รูปแบบ controller และระดับ sensor uncertainty (noise, delay) ส่งผลต่อความเร็ว ความถูกต้อง และความเสถียรของการตอบสนองของ reactive lamp อย่างไร โดยเทียบ C0 open loop, C1 single threshold, C2 filter + hysteresis และ C3 proportional + clamp ภายใต้ input trajectory 20 s ชุดเดียวกันใน simulator

## สมมติฐานก่อนทดลอง

เขียนก่อนรันการทดลองและก่อนเปิดไฟล์ผล คำนวณจากความชันของ trajectory ช่วงเข้า/ออก = 0.35 m / 4 s = 0.0875 m/s และ physical crossing ที่ 0.35 m เกิดที่ t ≈ 6.857 s (เข้า) และ 13.143 s (ออก)

1. **C1 กับ noise** — switching count จะเพิ่มขึ้นชัดเมื่อ noise เพิ่ม เพราะ C1 ใช้ raw distance เทียบ threshold เดียว ช่วงที่ระยะจริงอยู่ห่าง 0.35 m ไม่เกิน ~2σ ทำให้ state สลับไปมา (chatter) ช่วงนี้กว้าง ≈ ±2σ / 0.0875 m/s คือ ≈ ±0.23 s ที่ σ = 0.01 m และ ≈ ±0.69 s ที่ σ = 0.03 m จึงคาดว่า extra switches ที่ σ = 0.03 m จะมากกว่าที่ 0.01 m หลายเท่า ส่วนที่ σ = 0 จะเหลือ 2 ครั้งพอดี
2. **C2 แลก false trigger กับ latency** — filter β = 0.25 ลด SD ของ noise เหลือ ≈ 0.38σ และ hysteresis กว้าง 0.06 m จึงคาดว่า false trigger และ extra switches ≈ 0 ที่ σ = 0.01 m สิ่งที่ต้องแลกคือ latency: ระยะจริงต้องลงไปถึง 0.32 m (ช้ากว่า crossing ≈ 0.34 s) บวก filter lag ≈ 3 samples = 0.06 s รวมคาด latency enter และ exit ≈ 0.40 s ขณะที่ C1 คาด latency ≈ 0 s แต่ recovery time นานกว่าเพราะ chatter
3. **Sensor delay 300 ms** — ค่าที่ controller ได้รับเลื่อนหลังเหตุการณ์จริง 15 samples พอดี จึงคาดว่า latency ของ C2 เพิ่มขึ้น ≈ 0.30 s (เป็น ≈ 0.70 s) และช่วง 0.3 s แรกไม่มีข้อมูลใน buffer จะนับเป็น invalid samples 15 ค่าต่อ trial (5 ค่าที่ 100 ms)

## Block diagram ของ sensorimotor loop

ข้อมูลไหลจากระยะจริง d(t) ผ่าน sensor (noise, delay) → validity check → low-pass filter → controller → actuator ส่วน feedback ปิดวงผ่านโลกจริง คือแสงหรือการขยับของโคมทำให้คนขยับ แล้วระยะเปลี่ยน

![Block diagram ของ sensorimotor loop](fig1_block_diagram.png)

C1 ใช้ raw distance ข้ามตัว filter ส่วน C0 ไม่ใช้ sensor เลย sample ที่ invalid จะคง state เดิมและส่ง safe command u = 0 ใน simulator เส้น feedback นี้ **เปิดอยู่** เพราะ d(t) เป็น trajectory ที่กำหนดไว้ล่วงหน้า command จึงไม่ย้อนไปเปลี่ยนระยะ

## Protocol

ทุก trial ยาว 20 s, dt = 0.02 s (1001 samples), seed = 202602 + ลำดับ trial และใช้ `StudentController` ของกลุ่ม (`--controller-source student`) โดย trace ของโหมด student ตรงกับ reference ทุกแถว (20 ไฟล์, 0 แถวที่ต่างกัน)

| ชุดทดลอง | Controller | Noise σ (m) | Delay (ms) | Trials |
| --- | --- | --- | --- | --- |
| A: controller-comparison | C0–C3 | 0.01 | 0 | 5 × 4 = 20 |
| B: robustness-short | C2 | 0, 0.01, 0.03 | 0, 100, 300 (5 combinations) | 3 × 5 = 15 |
| B: robustness-full | C2 | 0, 0.01, 0.03 | 0, 100, 300 | 5 × 9 = 45 |
| เสริม: robustness-full | C1, C3 | 0, 0.01, 0.03 | 0, 100, 300 | 45 ต่อ controller |

Parameter: T = 0.35 m, T_enter/T_exit = 0.32/0.38 m, β = 0.25, Kp = 2.0, clamp [−0.6, 0.6] ชุดเสริม C1 ใช้ตอบ prediction ข้อ 1 และ C3 ใช้ตอบคำถามเรื่อง command limit

**ผลตรวจโค้ด:** `grade_submission.py` ผ่าน 10/10 (load, filter, single threshold, hysteresis, proportional/clamp, invalid sample, full trial C0–C3) unit tests ของ repo ก่อนเติม TODO ผ่าน 12/12 หลังเติมผ่าน 10/12 โดย 2 test ที่ไม่ผ่านคือ test ที่ตรวจว่า starter file ยังไม่เสร็จ ซึ่งคาดไว้แล้ว

## ผลทดลอง A — เปรียบเทียบ C0–C3

C2 เป็นแบบเดียวที่ไม่มี false trigger และ extra switches เลย โดยแลกกับ latency ≈ 0.41–0.45 s ส่วน C1 ตอบสนองเร็วที่สุด (≈ 0.02 s) แต่สลับ state เกินแผน 12.4 ครั้งต่อ trial (σ = 0.01 m, delay 0 ms, 5 trials ต่อ condition, ค่า mean ± SD จาก `summary_aggregate.csv`)

| Condition | Latency enter (s) | Latency exit (s) | Recovery (s) | False trigger (ครั้ง/นาที) | Extra switches | Mean \|Δu\| |
| --- | --- | --- | --- | --- | --- | --- |
| C0 open loop | 0.003 ± 0.000 | 2.857 ± 0.000 | 2.857 ± 0.000 | 3.00 ± 0.00 | 0.0 ± 0.0 | 0.0012 ± 0.0000 |
| C1 single threshold | 0.019 ± 0.026 | 0.029 ± 0.011 | 0.181 ± 0.059 | 8.39 ± 5.76 | 12.4 ± 2.6 | 0.0086 ± 0.0016 |
| C2 filter + hysteresis | 0.407 ± 0.043 | 0.453 ± 0.036 | 0.454 ± 0.035 | 0.00 ± 0.00 | 0.0 ± 0.0 | 0.0012 ± 0.0000 |
| C3 proportional + clamp | 0.043 ± 0.025 | 0.089 ± 0.042 | 0.109 ± 0.018 | 1.80 ± 1.64 | 1.6 ± 0.9 | 0.0046 ± 0.0001 |

C0 มี latency enter ต่ำเพียงเพราะเข้า NEAR ตามเวลาที่ 4.0 s ก่อน physical crossing (6.857 s) ถึง 2.857 s จึงถูกนับเป็น false trigger 1 ครั้งต่อ trial และออกช้า 2.857 s ค่า Mean |Δu| ของ C0 และ C2 เท่ากันพอดี (0.0012 = การกระโดด 0.6 สองครั้ง ÷ 1000 ช่วง) แม้ C0 ไม่ใช้ sensor เลย

**Controller ที่เลือกทดสอบ robustness:** C2 เพราะเป็นแบบเดียวที่ไม่มี false trigger ในชุด A จึงวัดได้ชัดว่า noise และ delay ทำให้ข้อดีนี้เสียไปหรือไม่ และ latency เปลี่ยนเท่าใด

**Invalid samples:** ชุด A มี 0 ค่า ไม่มี trial ที่ถูก exclude

## ผลทดลอง B — noise และ delay

C2 ไม่มี false trigger และ extra switches ใน 45 trials ของ robustness-full ส่วน delay ทำให้ latency เพิ่มเกือบเท่าค่า delay พอดี ขณะที่ C1 ที่ delay 0 ms มี extra switches เพิ่มจาก 0 เป็น 12.0 และ 39.2 ครั้งเมื่อ σ = 0, 0.01, 0.03 m

![(a) extra switches ของ C1 และ C2 ตาม noise, (b) latency enter ของ C2 ตาม delay](fig3_robustness.png)

ที่ σ = 0 latency enter ของ C2 เพิ่มจาก 0.423 s เป็น 0.523 s และ 0.723 s ที่ delay 100 และ 300 ms ส่วนที่ σ = 0.03 m ค่าเฉลี่ย latency ลดลงเล็กน้อย (0.407 s ที่ 0 ms) แต่ SD กว้างขึ้นเป็น 0.09–0.12 s ข้อมูลเต็มอยู่ใน `results/c2_full/summary_aggregate.csv` และ `results/c1_full/summary_aggregate.csv`

**Invalid samples:** ชุดที่มี delay มี 5 ค่า (100 ms) และ 15 ค่า (300 ms) ต่อ trial ทั้งหมดเป็น `MISSING_OR_DELAY_BUFFER` ช่วงต้น trial ที่ buffer ยังว่าง controller คง FAR และส่ง u = 0 จึงไม่ exclude trial ใด

## กราฟตัวแทน C1 และ C2

ใน trial r01 (σ = 0.01 m, delay 0 ms) ระยะจริงข้าม 0.35 m ที่ 6.857 s (เข้า) และ 13.143 s (ออก) C1 ตอบสนองถูกครั้งแรกหลัง crossing +0.003 s และ +0.017 s แต่สลับ state 9 และ 7 ครั้งในช่วงนั้น ส่วน C2 ตอบสนองที่ +0.383 s และ +0.437 s และเปลี่ยน state ครั้งเดียว

![C1 และ C2: physical crossing (เส้นประแดง) และ first correct response (เส้นม่วง)](fig2_C1_vs_C2_events.png)

C2 เข้า NEAR เมื่อ filtered distance ลงถึง T_enter = 0.32 m และออกเมื่อขึ้นถึง T_exit = 0.38 m ช่องว่างระหว่าง crossing กับเส้นม่วงจึงเป็นราคาของ hysteresis band ที่ทำให้ไม่เกิด chatter กราฟเต็ม 20 s ของแต่ละ trial อยู่ใน `results/figures/C1_trial1_annotated.png` และ `C2_trial1_annotated.png`

## คำถามวิเคราะห์

ข้อมูลสนับสนุน prediction ทั้ง 3 ข้อ แต่พบว่า C3 ไม่ชน command limit เลยใน scenario นี้

1. **C1 กับ C2 ต่างกันด้าน extra switches และ latency เท่าใด** — C1 มี extra switches 12.4 ± 2.6 ครั้ง ส่วน C2 มี 0 ครั้ง แต่ C2 มี latency enter 0.407 s เทียบกับ 0.019 s (ช้ากว่า 0.39 s) และ latency exit 0.453 s เทียบกับ 0.029 s ส่วน recovery time ต่างกันน้อยกว่า (0.454 เทียบกับ 0.181 s) เพราะ C1 ต้องรอ chatter หยุดก่อน ตรงกับ prediction ข้อ 2 ที่คาด latency ≈ 0.40 s
2. **noise 0.01 กับ 0.03 m ส่งผลต่อ metric ใดชัดที่สุด** — extra switches ของ C1 เพิ่มจาก 12.0 เป็น 39.2 ครั้ง (×3.3 ใกล้กับอัตราส่วน σ = 3 ตาม prediction ข้อ 1) และ false trigger เพิ่มจาก 12.6 เป็น 32.4 ครั้ง/นาที สำหรับ C2 ค่า false trigger ยังเป็น 0 สิ่งที่เปลี่ยนคือ SD ของ latency exit เพิ่มจาก 0.051 เป็น 0.089 s
3. **delay 300 ms ทำให้ latency เพิ่มใกล้ 300 ms หรือไม่** — ใช่ ที่ σ = 0 เพิ่ม 0.300 s พอดี (0.423 → 0.723 s) เพราะ delay เลื่อนสัญญาณทั้งเส้น 15 samples และ filter กับ hysteresis ไม่ขึ้นกับเวลา จึงเลื่อน response ตามไปเท่ากัน ที่ σ = 0.01 m เพิ่ม 0.27 s และที่ σ = 0.03 m เพิ่ม 0.19 s ความต่างนี้มาจาก noise แต่ละ trial ไม่ใช่ผลของ delay เพราะ SD ของจุดเหล่านี้คือ 0.06–0.12 s เมื่อมีเพียง 5 trials ตรงกับ prediction ข้อ 3
4. **C3 ชน command limit ช่วงใด และเหตุใด smoothness อย่างเดียวไม่พอ** — C3 ไม่ชน limit ±0.6 เลยในทุก trial (clamped samples = 0) |u| สูงสุด 0.53 ที่ σ = 0.01 m และ 0.57 ที่ σ = 0.03 m ในช่วงที่อยู่ไกล 0.60 m จะชน limit ได้เมื่อระยะ > 0.65 m หรือ < 0.05 m ซึ่ง trajectory นี้ไม่มี ส่วน smoothness ค่า Mean |Δu| ของ C0 และ C2 เท่ากันที่ 0.0012 ทั้งที่ C0 ไม่ใช้ sensor และมี false trigger 3.0 ครั้ง/นาที และ C3 มี |Δu| เพิ่มตาม noise (0.0019 → 0.0046 → 0.0129) พร้อม RMS error เทียบคำสั่งอุดมคติ Kp(0.35 − d) เพิ่ม 0.0077 → 0.0107 → 0.0239 จึงต้องดู smoothness ร่วมกับ latency และ tracking error
5. **มี invalid samples หรือไม่ และจัดการอย่างไร** — ชุด A ไม่มี ชุด B มี 5 หรือ 15 ค่าต่อ trial ตาม delay ทั้งหมดเกิดช่วงต้น trial ขณะ buffer ยังว่าง controller คง state FAR และใช้ safe command 0 ตามที่ออกแบบ จึงไม่ exclude trial และไม่แก้ raw CSV

![C3 command เทียบกับ clamp ±0.6](fig4_C3_command.png)

## ข้อจำกัดและสรุป

**สรุป:** ในเกณฑ์ false trigger และ extra switches C2 เป็นแบบเดียวที่ได้ 0 ในทุกระดับ noise และ delay ที่ทดสอบ แต่ต้องแลกกับ latency ≈ 0.4 s บวกค่า delay ส่วน C1 ตอบสนองเร็วที่สุดแต่ chatter เพิ่มตาม σ และ C0 ดูเร็วใน latency enter เพียงเพราะทำงานตามเวลา

**ข้อจำกัด:**

- **Simulator แทนหุ่นยนต์จริงไม่ได้:** noise เป็น Gaussian อิสระทุก sample และ delay คงที่ ขณะที่ sensor จริงมี bias, outlier, field of view และ dropout แบบกระจุก ส่วน actuator ในแบบจำลองไม่มีพลวัต เพราะ command ถูกนำไปใช้ทันที
- **Loop ยังไม่ปิดจริง:** d(t) กำหนดไว้ล่วงหน้า command จึงไม่ย้อนมาเปลี่ยนระยะ ผลนี้จึงบอกไม่ได้ว่าระบบปิดวงจะเสถียรหรือแกว่งหรือไม่
- **จำนวน trial น้อย:** 3–5 trials ต่อ combination ทำให้ SD ของ latency ที่ σ = 0.03 m กว้าง 0.09–0.12 s ความต่างระดับ 0.1 s จึงยังสรุปไม่ได้
- **Trajectory เดียว:** ความชัน 0.0875 m/s และระยะ 0.25–0.60 m ทำให้ C3 ไม่ชน clamp เลย ผลเรื่อง saturation จึงยังไม่ได้ทดสอบ
- **Parameter เป็น proposed course model:** ห้ามนำไปใช้กับหุ่นยนต์จริงก่อนตรวจ datasheet, limit และ emergency stop

ไม่มีการตัด trial หรือแก้ raw CSV ข้อมูลทั้งหมดสร้างซ้ำได้จาก `run_config.json` (seed_base 202602)
