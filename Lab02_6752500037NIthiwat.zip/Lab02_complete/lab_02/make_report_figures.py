"""Build the report figures for Lab 02 from the result folders.

Reads only raw CSV / summary files written by lab02.py; nothing is edited.
Usage: python make_report_figures.py --results results --out results/figures
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from plot_annotated import FILT, INK, RAW, THR, CMD, EVT, load_rows, trial_events

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


# ---------------------------------------------------------------- block diagram
def block_diagram(out: Path) -> None:
    fig, ax = plt.subplots(figsize=(13, 4.8))
    ax.set_xlim(0, 131)
    ax.set_ylim(0, 47)
    ax.axis("off")

    def box(x, y, w, h, title, sub, color):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.2",
                                    fc=color, ec="#333333", lw=1.1))
        if title:
            ax.text(x + w / 2, y + h - 2.2, title, ha="center", va="top", fontsize=9.5, weight="bold")
            ax.text(x + w / 2, y + (h - 4) / 2, sub, ha="center", va="center", fontsize=7.8, linespacing=1.35)
        else:
            ax.text(x + w / 2, y + h / 2, sub, ha="center", va="center", fontsize=7.8)

    def arrow(p0, p1, style="-", color="#333333", rad=0.0):
        ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=12, lw=1.3, color=color,
                                     linestyle=style, connectionstyle=f"arc3,rad={rad}", shrinkA=0, shrinkB=0))

    def path(points, style="-", color="#333333"):
        xs, ys = zip(*points[:-1])
        ax.plot(list(xs) + [points[-2][0]], list(ys) + [points[-2][1]], color=color, lw=1.3, ls=style)
        arrow(points[-2], points[-1], style=style, color=color)

    y, h = 22, 14
    boxes = {
        "env": (1, 16), "sen": (22, 19), "val": (46, 16), "fil": (67, 17), "ctl": (89, 21), "act": (115, 15),
    }
    box(*boxes["env"][:1], y, boxes["env"][1], h, "Environment", "hand / object\ntrue distance d(t)\n(ground truth)", "#EEF3F6")
    box(boxes["sen"][0], y, boxes["sen"][1], h, "Sensor", "d(t) + noise (sigma)\n+ delay tau\nrange 0.02-4.0 m", "#E7F1EE")
    box(boxes["val"][0], y, boxes["val"][1], h, "Validity check", "missing, non-finite\nor out of range?", "#F6F1E7")
    box(boxes["fil"][0], y, boxes["fil"][1], h, "Low-pass filter", "d_f[k] = b d[k]\n+ (1-b) d_f[k-1]\nb = 0.25", "#E7F1EE")
    box(boxes["ctl"][0], y, boxes["ctl"][1], h, "Controller", "C1: raw d < 0.35 m\nC2: hysteresis 0.32 / 0.38\nC3: Kp(0.35 - d_f), clamp", "#EAE6F3")
    box(boxes["act"][0], y, boxes["act"][1], h, "Actuator", "lamp command u\nC1, C2: 0.6 or 0\nC3: -0.6 ... 0.6", "#F6ECE7")

    order = ["env", "sen", "val", "fil", "ctl", "act"]
    labels = ["d(t)", "d_raw", "valid", "d_f", "u"]
    for a_key, b_key, lab in zip(order, order[1:], labels):
        x0 = boxes[a_key][0] + boxes[a_key][1] + 0.5
        x1 = boxes[b_key][0] - 0.5
        arrow((x0, 29), (x1, 29))
        ax.text((x0 + x1) / 2, 29.8, lab, ha="center", va="bottom", fontsize=7.6)

    # C1 bypasses the filter (top arc)
    arrow((56, 36.6), (95, 36.6), style="--", color="#555555", rad=-0.28)
    ax.text(75.5, 43.0, "C1 uses the raw value (bypasses filter)", ha="center", fontsize=7.8, color="#555555")
    # C0 open-loop clock
    box(113, 40.5, 17, 5, "", "C0: clock, NEAR 4-16 s", "#FFFFFF")
    arrow((121.5, 40.2), (121.5, 36.6), style=":", color="#555555")
    # invalid -> safe command (lower rail)
    path([(54, 21.7), (54, 15.5), (119, 15.5), (119, 21.7)], style="--", color=THR)
    ax.text(86.5, 16.2, "invalid sample: state held, safe command u = 0, event logged INVALID",
            ha="center", va="bottom", fontsize=7.8, color=THR)
    # physical feedback (bottom rail)
    path([(126, 21.7), (126, 8), (9, 8), (9, 21.7)], color="#1F5F8B")
    ax.text(67.5, 7.2, "feedback through the world: lamp moves or lights -> person reacts -> relative distance changes",
            ha="center", va="top", fontsize=7.8, color="#1F5F8B")
    ax.text(67.5, 3.6, "simulator: this path is open, d(t) is a fixed 20 s trajectory; metrics compare the state with d(t) < 0.35 m",
            ha="center", va="top", fontsize=7.6, color="#1F5F8B", style="italic")
    fig.savefig(out, dpi=170, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------- C1 vs C2 zoom
def c1_vs_c2(results: Path, out: Path) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(11, 5.4), sharey=True, constrained_layout=True)
    for row, cond in enumerate(("C1", "C2")):
        rows = load_rows(results / "student_comparison" / "trials" / f"{cond}_n0.01_d000_r01.csv")
        ev = trial_events(rows)
        t = [float(r["time_s"]) for r in rows]
        for col, key in enumerate(("enter", "exit")):
            ax = axes[row, col]
            cross = ev[f"{key}_cross"]
            lo, hi = cross - 0.6, cross + 0.9
            idx = [i for i, v in enumerate(t) if lo <= v <= hi]
            ts = [t[i] for i in idx]
            ax.plot(ts, [float(rows[i]["raw_distance_m"]) for i in idx], color=RAW, lw=0.9, label="raw")
            ax.plot(ts, [float(rows[i]["true_distance_m"]) for i in idx], color=INK, lw=1.8, label="true")
            if cond == "C2":
                ax.plot(ts, [float(rows[i]["filtered_distance_m"]) for i in idx], color=FILT, lw=1.6, label="filtered")
                ax.axhline(0.32, color=FILT, ls=":", lw=1.1, label="T_enter / T_exit")
                ax.axhline(0.38, color=FILT, ls=":", lw=1.1)
            ax.axhline(0.35, color=THR, ls="--", lw=1.1, label="T = 0.35 m")
            ax2 = ax.twinx()
            ax2.step(ts, [1 if rows[i]["state"] == "NEAR" else 0 for i in idx], where="post", color=CMD, lw=1.5)
            ax2.set_ylim(-0.15, 3.3)
            ax2.set_yticks([0, 1], ["FAR", "NEAR"])
            ax2.tick_params(colors=CMD)
            ax2.spines["right"].set_visible(True)
            ax.axvline(cross, color=THR, lw=1.2, ls="--")
            resp, lat = ev[f"{key}_resp"], ev[f"{key}_lat"]
            ax.axvline(resp, color=EVT, lw=1.5)
            switches = sum(1 for i in idx if rows[i]["event_label"] in ("ENTER_NEAR", "EXIT_NEAR"))
            ax.set_title(f"{cond} {'entering' if key == 'enter' else 'leaving'}: crossing {cross:.3f} s, "
                         f"first correct +{lat:.3f} s, {switches} switch{'es' if switches != 1 else ''} in window", fontsize=8.5, loc="left")
            ax.set_xlim(lo, hi)
            ax.set_ylim(0.27, 0.43)
            ax.grid(True, alpha=0.25)
            if col == 0:
                ax.set_ylabel(f"{cond}  distance (m)")
            if row == 1:
                ax.set_xlabel("time (s)")
            if row == 0 and col == 0:
                ax.legend(loc="upper right", fontsize=7, ncol=3)
            if row == 1 and col == 0:
                ax.legend(loc="lower left", fontsize=7, ncol=2)
    fig.suptitle("Trial r01, sigma = 0.01 m, delay 0 ms  |  red dashed = physical crossing, purple = first correct "
                 "response, orange = controller state", fontsize=9)
    fig.savefig(out, dpi=170)
    plt.close(fig)


# ---------------------------------------------------------------- robustness
def robustness(results: Path, out: Path) -> None:
    c1 = read_csv(results / "c1_full" / "summary_aggregate.csv")
    c2 = read_csv(results / "c2_full" / "summary_aggregate.csv")
    fig, (a, b) = plt.subplots(1, 2, figsize=(11, 3.9), constrained_layout=True)

    noises = ["0.0", "0.01", "0.03"]
    x = range(len(noises))
    for offset, data, name, color in ((-0.18, c1, "C1", THR), (0.18, c2, "C2", FILT)):
        rows = {r["noise_sigma_m"]: r for r in data if r["delay_ms"] == "0"}
        means = [float(rows[n]["extra_switches_mean"]) for n in noises]
        sds = [float(rows[n]["extra_switches_sd"]) for n in noises]
        bars = a.bar([i + offset for i in x], means, width=0.34, yerr=sds, capsize=3, color=color, label=name)
        for bar, m, sd in zip(bars, means, sds):
            a.text(bar.get_x() + bar.get_width() / 2, m + sd + 0.8, f"{m:.1f}", ha="center", fontsize=8)
    a.set_xticks(list(x), [f"{float(n):.2f}" for n in noises])
    a.set_xlabel("sensor noise sigma (m)")
    a.set_ylabel("extra switches per trial (mean +/- SD)")
    a.set_title("(a) Chatter vs noise, delay 0 ms, 5 trials each", loc="left", fontsize=9)
    a.legend()
    a.grid(True, axis="y", alpha=0.25)

    delays = [0, 100, 300]
    colors = {"0.0": "#161616", "0.01": FILT, "0.03": CMD}
    for i, n in enumerate(noises):
        rows = {int(r["delay_ms"]): r for r in c2 if r["noise_sigma_m"] == n}
        m = [float(rows[d]["latency_enter_s_mean"]) for d in delays]
        s = [float(rows[d]["latency_enter_s_sd"]) for d in delays]
        b.errorbar([d + (i - 1) * 6 for d in delays], m, yerr=s, marker="o", capsize=3, color=colors[n],
                   label=f"C2, sigma = {float(n):.2f} m")
    base = float({int(r["delay_ms"]): r for r in c2 if r["noise_sigma_m"] == "0.0"}[0]["latency_enter_s_mean"])
    b.plot(delays, [base + d / 1000 for d in delays], ls="--", color="#888888", lw=1, label="no-noise latency + delay")
    b.set_xticks(delays)
    b.set_xlabel("sensor delay (ms)")
    b.set_ylabel("enter latency (s, mean +/- SD)")
    b.set_title("(b) C2 latency vs delay, 5 trials per point", loc="left", fontsize=9)
    b.legend(fontsize=8)
    b.grid(True, alpha=0.25)
    fig.savefig(out, dpi=170)
    plt.close(fig)


# ---------------------------------------------------------------- C3 command
def c3_command(results: Path, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(11, 3.3), constrained_layout=True)
    for n, color in (("0.01", FILT), ("0.03", CMD)):
        rows = load_rows(results / "c3_full" / "trials" / f"C3_n{n}_d000_r01.csv")
        t = [float(r["time_s"]) for r in rows]
        u = [float(r["command"]) for r in rows]
        ax.plot(t, u, color=color, lw=1.1, label=f"C3 command, sigma = {float(n):.2f} m (min {min(u):.3f}, max {max(u):.3f})")
    ideal = [max(-0.6, min(0.6, 2.0 * (0.35 - float(r["true_distance_m"])))) for r in rows]
    ax.plot(t, ideal, color=INK, lw=1.4, ls="--", label="Kp(0.35 - true distance)")
    for lim in (-0.6, 0.6):
        ax.axhline(lim, color=THR, lw=1.3)
    ax.text(0.2, 0.62, "command_max = +0.6", color=THR, fontsize=8)
    ax.text(0.2, -0.66, "command_min = -0.6", color=THR, fontsize=8, va="top")
    ax.set_ylim(-0.75, 0.95)
    ax.set_xlabel("time (s)")
    ax.set_ylabel("command u")
    ax.set_title("C3 never reaches the clamp: |u| peaks at about 0.57 when far (0.60 m); limit would need d > 0.65 m or d < 0.05 m",
                 loc="left", fontsize=9)
    ax.legend(loc="upper center", fontsize=7.5, ncol=3, framealpha=0.95)
    ax.grid(True, alpha=0.25)
    fig.savefig(out, dpi=170)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=Path("results"))
    parser.add_argument("--out", type=Path, default=Path("results/figures"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    block_diagram(args.out / "fig1_block_diagram.png")
    c1_vs_c2(args.results, args.out / "fig2_C1_vs_C2_events.png")
    robustness(args.results, args.out / "fig3_robustness.png")
    c3_command(args.results, args.out / "fig4_C3_command.png")
    print(f"wrote figures to: {args.out.resolve()}")


if __name__ == "__main__":
    main()
