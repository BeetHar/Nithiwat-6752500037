"""Annotated Lab 02 trial plot.

Extends plot_trial.py: marks the physical threshold crossing (true distance
crosses T = 0.35 m) and the first correct response for enter and exit, and adds
zoom panels around both events. Event times use the same functions as the
metric code in lab02.py, so the marked latencies equal summary_trials.csv.
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from lab02 import LabConfig, _crossing_time, _first_correct_latency

INK = "#161616"
RAW = "#A7ADB1"
FILT = "#147A8C"
THR = "#B84A4A"
CMD = "#C17824"
EVT = "#6B3FA0"


def optional_float(value: str) -> float | None:
    return None if value == "" else float(value)


def load_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def trial_events(rows: list[dict[str, str]], config: LabConfig | None = None) -> dict[str, float | None]:
    config = config or LabConfig()
    enter_cross = _crossing_time(rows, "down", config.threshold_m)
    exit_cross = _crossing_time(rows, "up", config.threshold_m)
    enter_lat = _first_correct_latency(rows, enter_cross, "NEAR")
    exit_lat = _first_correct_latency(rows, exit_cross, "FAR")
    return {
        "enter_cross": enter_cross,
        "exit_cross": exit_cross,
        "enter_resp": None if enter_lat is None else enter_cross + enter_lat,
        "exit_resp": None if exit_lat is None else exit_cross + exit_lat,
        "enter_lat": enter_lat,
        "exit_lat": exit_lat,
    }


def draw_distance(ax, rows, t, condition, show_legend=True) -> None:
    true_d = [float(r["true_distance_m"]) for r in rows]
    raw_d = [optional_float(r["raw_distance_m"]) for r in rows]
    filt_d = [optional_float(r["filtered_distance_m"]) for r in rows]
    ax.plot(t, raw_d, color=RAW, lw=0.9, alpha=0.9, label="raw (sensor)")
    ax.plot(t, true_d, color=INK, lw=2, label="true distance")
    if condition != "C1" and any(v is not None for v in filt_d):
        ax.plot(t, filt_d, color=FILT, lw=1.8, label="filtered")
    ax.axhline(0.35, color=THR, ls="--", lw=1.3, label="T = 0.35 m")
    if condition == "C2":
        ax.axhline(0.32, color=FILT, ls=":", lw=1.2, label="T_enter 0.32")
        ax.axhline(0.38, color=CMD, ls=":", lw=1.2, label="T_exit 0.38")
    ax.set_ylabel("distance (m)")
    ax.grid(True, alpha=0.25)
    if show_legend:
        ax.legend(loc="upper center", ncol=6, fontsize=8, framealpha=0.9)


def draw_state(ax, rows, t, show_command=True) -> None:
    state = [1 if r["state"] == "NEAR" else 0 for r in rows]
    ax.step(t, state, where="post", color=FILT, lw=1.6, label="state (NEAR = 1)")
    if show_command:
        ax.plot(t, [float(r["command"]) for r in rows], color=CMD, lw=1.6, label="command u")
    ax.set_ylabel("state / command")
    ax.grid(True, alpha=0.25)


def mark_events(ax, ev, label=True, y=1.08) -> None:
    for key, name in (("enter", "enter"), ("exit", "exit")):
        cross, resp, lat = ev[f"{key}_cross"], ev[f"{key}_resp"], ev[f"{key}_lat"]
        if cross is not None:
            ax.axvline(cross, color=THR, lw=1.2, ls="--")
        if resp is not None:
            ax.axvline(resp, color=EVT, lw=1.4)
            if label and lat is not None:
                ax.annotate(
                    f"{name}: +{lat:.3f} s",
                    xy=(resp, y), xycoords=("data", "axes fraction"),
                    ha="left", va="bottom", fontsize=8, color=EVT,
                )


def plot_annotated(csv_path: Path, output_path: Path) -> dict[str, float | None]:
    rows = load_rows(csv_path)
    if not rows:
        raise ValueError(f"empty CSV: {csv_path}")
    t = [float(r["time_s"]) for r in rows]
    condition = rows[0]["condition"]
    ev = trial_events(rows)

    fig = plt.figure(figsize=(12, 9), constrained_layout=True)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.1, 0.8, 1.1])
    ax_d = fig.add_subplot(gs[0, :])
    ax_s = fig.add_subplot(gs[1, :], sharex=ax_d)
    ax_ze = fig.add_subplot(gs[2, 0])
    ax_zx = fig.add_subplot(gs[2, 1])

    draw_distance(ax_d, rows, t, condition)
    ax_d.set_ylim(0.18, 0.72)
    draw_state(ax_s, rows, t)
    ax_s.set_ylim(-0.7, 1.25)
    ax_s.legend(loc="lower center", ncol=2, fontsize=8)
    mark_events(ax_s, ev, label=False)
    for ax in (ax_d,):
        for key in ("enter_cross", "exit_cross"):
            if ev[key] is not None:
                ax.axvline(ev[key], color=THR, lw=1.0, ls="--", alpha=0.7)
    ax_s.set_xlabel("time (s)")

    for ax, key, title in ((ax_ze, "enter", "zoom: entering"), (ax_zx, "exit", "zoom: leaving")):
        cross = ev[f"{key}_cross"]
        lo, hi = (cross - 0.7, cross + 1.0) if cross is not None else (0, 20)
        idx = [i for i, v in enumerate(t) if lo <= v <= hi]
        sub = [rows[i] for i in idx]
        ts = [t[i] for i in idx]
        draw_distance(ax, sub, ts, condition, show_legend=False)
        ax2 = ax.twinx()
        ax2.step(ts, [1 if r["state"] == "NEAR" else 0 for r in sub], where="post", color=FILT, lw=1.4, alpha=0.8)
        ax2.set_ylim(-0.2, 3.2)
        ax2.set_yticks([0, 1], ["FAR", "NEAR"])
        mark_events(ax, {k: v for k, v in ev.items()} | {
            ("exit" if key == "enter" else "enter") + "_cross": None,
            ("exit" if key == "enter" else "enter") + "_resp": None,
        }, y=1.01)
        ax.set_xlim(lo, hi)
        ax.set_ylim(0.26, 0.44)
        ax.set_title(title, fontsize=10, loc="left")
        ax.set_xlabel("time (s)")

    fig.suptitle(
        f"{rows[0]['trial_id']} | {condition} | sigma={rows[0]['noise_sigma_m']} m | delay={rows[0]['delay_ms']} ms"
        f"   (dashed red = physical crossing of 0.35 m, purple = first correct response)",
        fontsize=10,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    return ev


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path", type=Path)
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()
    out = args.out or args.csv_path.with_name(args.csv_path.stem + "_annotated.png")
    ev = plot_annotated(args.csv_path, out)
    print(f"wrote plot to: {out.resolve()}")
    for key, value in ev.items():
        print(f"  {key}: {'N/A' if value is None else f'{value:.4f} s'}")


if __name__ == "__main__":
    main()
