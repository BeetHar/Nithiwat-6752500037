"""Build Lab 03 report figures from the CSV files written by the simulators.

Usage (from lab_03): python make_lab03_figures.py
Reads results/gait_comparison/*.csv and results/week4_bridge/week4_bridge.csv.
Requires matplotlib.
"""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

RES = Path("results")
OUT = RES / "figures"
COLORS = {"baseline": "#161616", "fast": "#147A8C", "high_gain": "#C17824"}
LEGS_A = ("LF", "RM", "LH")
LEGS_B = ("RF", "LM", "RH")
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})


def load(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def col(rows, name):
    return [float(r[name]) for r in rows]


def fig_cpg(data) -> None:
    fig, (a, b) = plt.subplots(1, 2, figsize=(11, 3.8), gridspec_kw={"width_ratios": [2.2, 1]},
                               constrained_layout=True)
    for name, rows in data.items():
        t = col(rows, "time_s")
        idx = [i for i, v in enumerate(t) if v <= 5.0]
        a.plot([t[i] for i in idx], [float(rows[i]["o1"]) for i in idx], color=COLORS[name], lw=1.6,
               label=f"{name} o1")
        b.plot(col(rows, "o1"), col(rows, "o2"), color=COLORS[name], lw=1.2, label=name)
    a.axhline(0, color="#999999", lw=0.8)
    a.set_xlabel("time after warmup (s)")
    a.set_ylabel("o1")
    a.set_title("(a) CPG output o1, first 5 s  (fast: shorter period; high_gain: larger amplitude, longer period)",
                loc="left", fontsize=9)
    a.legend(fontsize=8, ncol=3, loc="lower left")
    a.grid(True, alpha=0.25)
    b.set_aspect("equal")
    b.set_xlabel("o1")
    b.set_ylabel("o2")
    b.set_title("(b) limit cycle o1 vs o2", loc="left", fontsize=9)
    b.legend(fontsize=8, loc="upper right")
    b.grid(True, alpha=0.25)
    fig.savefig(OUT / "fig1_cpg_output.png", dpi=170)
    plt.close(fig)


def fig_gait(rows) -> None:
    t = col(rows, "time_s")
    idx = [i for i, v in enumerate(t) if v <= 4.8]
    fig, (a, b) = plt.subplots(2, 1, figsize=(11, 4.2), sharex=True,
                               gridspec_kw={"height_ratios": [3, 1.1]}, constrained_layout=True)
    legs = LEGS_A + LEGS_B
    for k, leg in enumerate(legs):
        y = len(legs) - 1 - k
        color = "#147A8C" if leg in LEGS_A else "#C17824"
        start = None
        for i in idx:
            stance = rows[i][f"{leg}_contact"] == "1"
            if stance and start is None:
                start = t[i]
            if (not stance or i == idx[-1]) and start is not None:
                a.broken_barh([(start, t[i] - start)], (y - 0.35, 0.7), color=color)
                start = None
    a.set_yticks(range(len(legs)), [f"{leg} ({'A' if leg in LEGS_A else 'B'})" for leg in legs][::-1])
    a.set_title("Baseline gait diagram: bar = stance (foot on ground), gap = swing. "
                "Tripod A (LF, RM, LH) and B (RF, LM, RH) alternate; measured lag 0.80 s = 180 deg",
                loc="left", fontsize=9)
    a.grid(True, axis="x", alpha=0.25)
    b.step([t[i] for i in idx], [int(rows[i]["support_legs"]) for i in idx], where="post", color="#161616", lw=1.5)
    b.set_ylim(0, 6.5)
    b.set_yticks([0, 3, 6])
    b.set_ylabel("support legs")
    b.set_xlabel("time after warmup (s)")
    b.grid(True, alpha=0.25)
    fig.savefig(OUT / "fig2_gait_diagram_baseline.png", dpi=170)
    plt.close(fig)


def fig_compare(summary) -> None:
    names = [r["condition"] for r in summary]
    metrics = [
        ("oscillation_frequency_hz", "frequency (Hz)", 1, "{:.3f}"),
        ("mean_speed_m_s", "mean speed (m/s)", 1, "{:.4f}"),
        ("maximum_foot_clearance_m", "max foot clearance (mm)", 1000, "{:.2f}"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.3), constrained_layout=True)
    for ax, (key, label, scale, fmt) in zip(axes, metrics):
        vals = [float(r[key]) * scale for r in summary]
        bars = ax.bar(names, vals, color=[COLORS[n] for n in names])
        base = vals[0]
        for bar, v in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2, v * 1.02, fmt.format(v) + f"\n(x{v / base:.2f})",
                    ha="center", va="bottom", fontsize=8)
        ax.set_ylim(0, max(vals) * 1.3)
        ax.set_title(label, loc="left", fontsize=9)
        ax.grid(True, axis="y", alpha=0.25)
    fig.suptitle("Gait comparison, one variable changed per condition (fast: phi 0.20 -> 0.40 rad; "
                 "high_gain: alpha 1.10 -> 1.30); ratio vs baseline in brackets", fontsize=9)
    fig.savefig(OUT / "fig3_gait_comparison.png", dpi=170)
    plt.close(fig)


def fig_bridge(rows) -> None:
    t = col(rows, "time_s")
    o1 = col(rows, "o1")
    cross = [i for i in range(1, len(o1)) if o1[i - 1] <= 0.0 < o1[i]]
    ct = [t[cross[k]] for k in range(1, len(cross))]
    per = [t[cross[k]] - t[cross[k - 1]] for k in range(1, len(cross))]
    fig, axes = plt.subplots(4, 1, figsize=(11, 6.2), sharex=True, constrained_layout=True)
    axes[0].step(t, col(rows, "modulator_m"), where="post", color="#161616", lw=1.6)
    axes[0].set_ylabel("m(t)")
    axes[0].set_ylim(-0.2, 1.3)
    ax = axes[1]
    ax.step(t, col(rows, "phi_rad"), where="post", color="#147A8C", lw=1.6, label="phi cmd (rad)")
    ax2 = ax.twinx()
    ax2.step(t, col(rows, "stride_half_m"), where="post", color="#C17824", lw=1.4, ls="--", label="stride cmd (m)")
    ax2.spines["right"].set_visible(True)
    ax.set_ylabel("phi (rad)", color="#147A8C")
    ax2.set_ylabel("stride (m)", color="#C17824")
    ax.set_ylim(0.1, 0.45)
    ax2.set_ylim(0.040, 0.070)
    axes[2].plot(ct, per, "o-", color="#161616", ms=4)
    for x, p in zip(ct, per):
        if 0.9 < p < 1.5:  # between the two steady periods = cycle that straddles a switch
            axes[2].annotate(f"{p:.2f} s mixed cycle", (x, p), textcoords="offset points", xytext=(6, 4), fontsize=8)
    axes[2].set_ylabel("cycle period (s)")
    axes[2].set_ylim(0.5, 1.9)
    axes[3].plot(t, col(rows, "body_x_m"), color="#161616", lw=1.6)
    axes[3].set_ylabel("body x (m)")
    axes[3].set_xlabel("time (s)")
    for axx in axes:
        axx.grid(True, alpha=0.25)
        for edge in (10, 20):
            axx.axvline(edge, color="#B84A4A", lw=1, ls=":")
    axes[0].set_title("Week 4 bridge: bounded mapping phi = clamp(0.20 + 0.20m, 0.10, 0.45), "
                      "stride = clamp(0.055 + 0.010m, 0.040, 0.070)", loc="left", fontsize=9)
    fig.savefig(OUT / "fig4_week4_bridge.png", dpi=170)
    plt.close(fig)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    data = {n: load(RES / "gait_comparison" / f"{n}.csv") for n in ("baseline", "fast", "high_gain")}
    fig_cpg(data)
    fig_gait(data["baseline"])
    fig_compare(load(RES / "gait_comparison" / "conditions_summary.csv"))
    fig_bridge(load(RES / "week4_bridge" / "week4_bridge.csv"))
    print(f"wrote figures to {OUT.resolve()}")


if __name__ == "__main__":
    main()
