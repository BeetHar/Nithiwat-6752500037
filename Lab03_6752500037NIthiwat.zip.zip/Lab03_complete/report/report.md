# รายงาน Lab 03 — SO(2) CPG และการเดินแบบ alternating tripod

ชื่อกลุ่ม ________ · สมาชิก ________ · วันที่ ________

## คำถามวิจัย

การเปลี่ยน recurrent gain α และ phase increment φ ส่งผลต่อจังหวะ CPG การสลับ tripod และตัวชี้วัดการเดินใน kinematic simulation อย่างไร และ input ที่เปลี่ยนช้ากว่า CPG จะปรับ φ กับ stride ภายใต้ bounds ได้อย่างไร โดยไม่สั่งมอเตอร์โดยตรง

## สมมติฐานก่อนทดลองเทียบกับผล

| ข้อ | Prediction (จากใบงาน) | ผลที่วัดได้ | สรุป |
| --- | --- | --- | --- |
| 1 | φ 0.20 → 0.40 rad ทำให้ความถี่เพิ่ม ≈ 2 เท่า (f ≈ φ/2π·dt) | 0.625 → 1.267 Hz (×2.03) | สนับสนุน |
| 2 | α 1.10 → 1.30 ทำให้แอมพลิจูดและ clearance เพิ่ม | o₂ สูงสุด 0.570 → 0.821, clearance 17.09 → 24.64 mm (×1.44) | สนับสนุน แต่ไม่ได้คาดว่า frequency จะลดลง 13% |
| 3 | Tripod A และ B ต่างเฟส 180° | swing onset ของ LF กับ RF ห่างกัน 0.80 s จากคาบ 1.60 s = 180.0° | สนับสนุน |
| 4 | Simulator วัด dynamic stability, force, torque, energy ไม่ได้ | ไม่มี output ของค่าเหล่านี้ | สนับสนุน |

## ค่าที่ตั้ง (controlled parameters)

| Parameter | baseline | fast | high_gain |
| --- | --- | --- | --- |
| α | 1.10 | 1.10 | **1.30** |
| φ (rad) | 0.20 | **0.40** | 0.20 |

ค่าที่คงเดิมทุกเงื่อนไข: dt = 0.05 s, duration 30 s, warmup 10 s, initial condition o₁ = 0.10 และ o₂ = 0.00, stride_half = 0.055 m, lift height = 0.03 m ในแต่ละเงื่อนไขเปลี่ยนตัวแปรเพียงตัวเดียว จึงระบุสาเหตุของความต่างได้

**ตรวจโค้ด:** `grade_submission.py` ผ่าน 5/5 checks (ไม่มี TODO ค้าง, สมการ SO(2), simultaneous update, alternating tripod decoder, bounded handoff) การคำนวณมือหนึ่ง time step ที่ o₁ = 0.10, o₂ = −0.20, α = 1.10, φ = 0.20 rad ได้ o₁(t+1) = 0.064012 และ o₂(t+1) = −0.233103 ตรงกับ `so2_step`

## ค่าที่วัด (measured metrics)

fast มี frequency และ speed เพิ่มประมาณ 2 เท่าโดย clearance ไม่เปลี่ยน ส่วน high_gain มี clearance เพิ่ม 44% แต่ frequency ลดลง 13% (จาก `results/gait_comparison/conditions_summary.csv`)

| Condition | Speed (m/s) | Frequency (Hz) | Duty factor LF | Min support | Clearance (mm) |
| --- | --- | --- | --- | --- | --- |
| baseline | 0.0778 | 0.625 | 0.494 | 3 | 17.09 |
| fast | 0.1555 | 1.267 | 0.501 | 3 | 17.11 |
| high_gain | 0.0945 | 0.544 | 0.494 | 3 | 24.64 |

![เทียบ frequency, speed และ clearance ของ 3 เงื่อนไข](fig3_gait_comparison.png)

![Output ของ CPG และ limit cycle](fig1_cpg_output.png)

![Gait diagram ของ baseline: Tripod A และ B สลับกัน และมีขารองรับ 3 ขาตลอด](fig2_gait_diagram_baseline.png)

## กลไก

- **φ กำหนดจังหวะ:** φ คือมุมที่ state (o₁, o₂) หมุนต่อ step ค่าทฤษฎีจึงเป็น f ≈ φ/(2π·dt) = 0.637 Hz ที่ φ = 0.20 rad แต่วัดได้ 0.625 Hz (คาบ 1.60 s = 32 steps) เพราะ zero crossing ถูก quantize ด้วย dt ส่วน fast มีคาบสลับกันระหว่าง 0.75 กับ 0.80 s
- **α กำหนดแอมพลิจูด:** α ที่สูงทำให้ limit cycle ใหญ่ขึ้นและ tanh เข้าใกล้ saturation รูปคลื่นจึงเหลี่ยมขึ้น (รูป 1b) และมุมที่หมุนจริงต่อ step น้อยกว่า φ ทำให้คาบยาวขึ้นเป็น 1.84 s
- **Clearance ตาม o₂ โดยตรง:** clearance = lift_height × o₂ สูงสุด ได้ 0.03 × 0.570 = 17.1 mm และ 0.03 × 0.821 = 24.6 mm ตรงกับค่าที่วัด
- **Speed ตามทั้งแอมพลิจูดและความถี่:** ใน stance เท้าเลื่อนจาก +A·stride_half ถึง −A·stride_half ทุกครึ่งรอบ จึงได้ speed ≈ 4 × stride_half × A × f ที่ baseline คำนวณได้ 4 × 0.055 × 0.570 × 0.625 = 0.078 m/s ตรงกับค่าที่วัด ส่วน high_gain ได้ 0.098 เทียบกับที่วัดได้ 0.0945 m/s เพราะรูปคลื่นไม่ใช่ไซน์ ข้อนี้อธิบายว่าทำไม high_gain เร็วขึ้น 21% ทั้งที่ frequency ลดลง
- **Tripod decoder:** Tripod A ใช้ sign +1 และ Tripod B ใช้ sign −1 กับกฎ contact = sign·o₂ ≤ 0 จึงมี tripod เดียวใน stance ทุก sample ทำให้ LF กับ RF มี contact ตรงข้ามกัน 100% ของ samples และ duty factor ≈ 0.5

## Week 4 handoff

| ช่วงเวลา | m(t) | φ cmd (rad) | stride cmd (m) | Speed (m/s) | Frequency (Hz) |
| --- | --- | --- | --- | --- | --- |
| 0–10 s | 0 | 0.20 | 0.055 | 0.0776 | 0.625 |
| 10–20 s | 1 | 0.40 | 0.065 | 0.1833 | 1.263 |
| 20–30 s | 0 | 0.20 | 0.055 | 0.0774 | 0.625 |

![Week 4 bridge: m(t), คำสั่งที่ผ่าน bounded mapping, คาบแต่ละรอบ และตำแหน่งลำตัว](fig4_week4_bridge.png)

ช่วง 10–20 s เร็วกว่า fast (0.1833 เทียบกับ 0.1555 m/s) เพราะ stride เพิ่มจาก 0.055 เป็น 0.065 m ด้วย (อัตราส่วน 1.18) ทุกคำสั่งอยู่ใน bounds จึงไม่มีค่าใดถูก clamp

## คำถามวิเคราะห์

1. **fast ต่างจาก baseline เท่าใด** — frequency เพิ่ม 0.642 Hz (1.267 เทียบกับ 0.625 Hz, ×2.03) และ speed เพิ่ม 0.0778 m/s (0.1555 เทียบกับ 0.0778 m/s, ×2.00)
2. **high_gain เปลี่ยน clearance และ frequency ไปทิศทางเดียวกันหรือไม่** — ไม่ใช่ clearance เพิ่ม 7.54 mm (+44%) แต่ frequency ลดลง 0.081 Hz (−13%) ดังนั้น φ จึงไม่ใช่ตัวกำหนดความถี่เพียงตัวเดียว ต้องวัด output ทุกครั้ง
3. **Support legs ต่ำกว่า 3 หรือไม่** — ไม่ต่ำกว่า เพราะทุกเงื่อนไขมี min = max = 3 สาเหตุคือกฎ contact = sign·o₂ ≤ 0 ที่สอง tripod มี sign ตรงข้ามกัน จึงมีหนึ่ง tripod ใน stance เสมอ ผลนี้เป็นผลจากกฎ decoder ไม่ใช่หลักฐานว่าหุ่นยนต์ทรงตัวได้
4. **เมื่อ m กลับจาก 1 เป็น 0 output กลับ baseline ทันทีหรือไม่** — คำสั่ง φ และ stride กลับทันทีเพราะ mapping ไม่มี filter แต่ CPG ไม่ถูก reset จึงมี 1 รอบผสม (คาบ 1.25 s) ก่อนกลับเป็น 1.60 s แอมพลิจูดคงเดิมเพราะ α ไม่เปลี่ยน speed ช่วง 20–30 s เท่ากับ 0.0774 m/s ต่างจากช่วง 0–10 s เพียง 0.3% จึงเป็น transient สั้นแค่รอบเดียว
5. **ทำไม Week 4 ควรส่ง hormone ผ่าน receptor และ bounded mapping** — hormone เปลี่ยนช้าและอาจมีค่าเกินช่วง ถ้าสั่งมอเตอร์ตรงจะข้าม CPG และเสียการประสานงานของ tripod การปรับแค่ φ และ stride ทำให้ CPG ยังสร้าง pattern ที่ถูกต้องเสมอ bounds รับประกันว่าคำสั่งอยู่ในช่วงที่ทดสอบแล้ว (m = 99 ยังได้ φ = 0.45 rad, stride = 0.070 m) และ mapping เดิมทำให้เทียบกับ Week 3 ได้อย่างเป็นธรรม
6. **ถ้าต้องพิสูจน์ dynamic stability ต้องเพิ่มอะไร** — ต้องเพิ่ม rigid-body dynamics (มวล, inertia, แรงโน้มถ่วง), contact และ friction model และ actuator/torque model ส่วน metric ที่ต้องวัดคือ center of mass หรือ ZMP เทียบกับ support polygon (stability margin), ground reaction force, slip, body roll/pitch, joint torque และ cost of transport

## ข้อจำกัด

- **เป็น kinematic model:** ไม่มีมวล แรงโน้มถ่วง แรงปฏิกิริยาจากพื้น แรงเสียดทาน torque หรือพลังงาน ลำตัวเคลื่อนโดยสมมติว่าเท้าใน stance ไม่ลื่น
- **Contact เป็นกฎ ไม่ใช่การแตะพื้นจริง:** support 3 ขาเป็นเพียง static support ตามกฎ sign·o₂ ≤ 0 ไม่ได้พิสูจน์ dynamic stability
- **ความละเอียดของการวัด:** frequency ที่วัดจาก zero crossing ถูก quantize ด้วย dt = 0.05 s และ duty factor 0.494 ต่างจาก 0.5 เพราะหน้าต่าง 30 s ไม่ได้ครบรอบพอดี
- **ทดสอบแค่ 3 จุด:** แต่ละตัวแปรมีเพียง 2 ระดับ จึงยังไม่รู้รูปความสัมพันธ์ระหว่าง α, φ กับ frequency ในช่วงกว้าง ผลเป็นแบบ deterministic จึงไม่มี trial ซ้ำ
- **m(t) ยังไม่ใช่ hormone:** เป็น step ที่กำหนดเอง ไม่มีพลวัต production, decay หรือ receptor
- **Parameter เป็น proposed course model:** ห้ามนำไปใช้กับหุ่นยนต์จริงก่อนตรวจ joint limit, actuator และความปลอดภัย

ไม่มีการแก้ raw CSV ผลทั้งหมดสร้างซ้ำได้จากคำสั่งใน README
