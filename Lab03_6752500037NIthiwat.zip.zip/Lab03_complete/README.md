# Lab 03 — SO(2) CPG และการเดินแบบ alternating tripod (ไฟล์ทั้งหมด)

## โครงสร้าง
- report/Lab03_Report.docx, .pdf, .md — รายงาน (ต้องใส่ชื่อกลุ่ม สมาชิก และวันที่เอง)
- lab_03/ — โฟลเดอร์แล็บทั้งหมด พร้อมรัน
  - worksheet.md — ใบงานที่กรอกครบ (ต้องใส่ชื่อกลุ่ม สมาชิก และวันที่เอง)
  - student_cpg.py — TODO 1–3 เติมแล้ว (grade 5/5)
  - make_lab03_figures.py — สคริปต์สร้างกราฟในรายงาน (ต้องมี matplotlib)
  - results/my_grade.json — ผล grade_submission.py
  - results/gait_comparison/ — raw CSV, SVG, summary ของ baseline, fast, high_gain
  - results/week4_bridge/ — week4_bridge.csv และ handoff_contract.json
  - results/smoke_test/ — ผลทดสอบ 2 s ตามขั้นเตรียมสภาพแวดล้อม
  - results/figures/ — กราฟ 4 รูปในรายงาน

## ที่ต้องทำเอง
1. ใส่ชื่อกลุ่ม สมาชิก และวันที่ใน report/Lab03_Report.docx และ lab_03/worksheet.md
2. รันซ้ำบนเครื่องตัวเอง จากโฟลเดอร์ lab_03 (ผลเท่าเดิม แต่ path ใน my_grade.json จะเป็นของเครื่องเรา)

   $env:PYTHONUTF8=1
   python grade_submission.py --student-file student_cpg.py --out results\my_grade.json
   python cpg_walk_sim.py --condition all --output-dir results\gait_comparison
   python week4_bridge.py --output-dir results\week4_bridge

3. เปิด hexapod_cpg_sim.html (ขั้นทดลอง A) ดูเองในเบราว์เซอร์ กด Baseline, Fast, High gain
